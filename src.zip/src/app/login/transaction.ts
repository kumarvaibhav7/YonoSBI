export class Transaction {
    acnumber:number|undefined;
    dateoftran:any|undefined;
    from_to:number|undefined;
    medium_of_tran:string|undefined;
    tran_amount:number|undefined;
    tranid:string|undefined;

}

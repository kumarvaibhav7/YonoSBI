export class Customer {
    aadhaar:String|undefined;
    city:String|undefined;
    country:String|undefined;
    dateofbirth:any|undefined;
    fname:String|undefined;
    houseno:any|undefined;
    lname:String|undefined;
    locality:String|undefined;
    mobileno:any|undefined;
    mstatus:String|undefined;
    pincode:any|undefined;
    state:String|undefined;
}

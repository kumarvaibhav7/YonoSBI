import { Cusaccount } from './cusaccount';

describe('Cusaccount', () => {
  it('should create an instance', () => {
    expect(new Cusaccount()).toBeTruthy();
  });
});

import { Customer } from "./customer";

export class Cusaccount {
    atype:String|undefined;
    bid:any|undefined;
    acnumber:any|undefined;
    accopendate:any|undefined;
    astatus:any|undefined;
    balance:any|undefined;
    customer:Customer|undefined;

}

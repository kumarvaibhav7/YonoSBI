export class Branch {
    bid:number|undefined;
    bcode:string|undefined;
    bname:string|undefined;
    bcity:string|undefined;
}

import { Cusaccount } from "./cusaccount";

export class Credentials {
    username:String|undefined;
    password:String|undefined;
    account:Cusaccount|undefined;
}
